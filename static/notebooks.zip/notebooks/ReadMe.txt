In the folder there are two notebooks: "Part1" and "Part2".

The reading should start from the "Part1" notebook that contains the motivations, the process of retrieving the data, the creation of the network, the analysis of the topology of the network and of the communities.
The "Part2" notebook contains the sentiment analysis and the NLP part in general.
Finally, the conclusions and the contributions are again in the "Part1" notebook.   

As we wrote the notebook in Google Colab, it is recommend to open them in the same platform in order to avoid any compatibility problem.

Good reading!